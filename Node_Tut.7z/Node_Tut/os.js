const os = require('os')
console.log(os.platform(),os.homedir())
// console.log(os.homedir)
