// global.setTimeout(() => {
//     console.log("Hello World in 3sec")
// }, 3000);

// global.setInterval(() => {
//     console.log("6 Sec")
// },6000)


// global.setTimeout(() => {
//     console.log("Times Up")
//     clearInterval(run1)
// }, 10000)

// const run1 = setInterval(() => {
//     console.log("Running")
// }, 1000)
let nom = 0

const runn1 = setInterval(() => {
    nom=+1
    console.log(nom)
},1000)

setTimeout(() => {
    console.log("Ten")
    clearInterval(runn)
}, 10000)
