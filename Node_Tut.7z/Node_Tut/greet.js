const greets = (name) => {
    console.log(`Welcome ${name}`);
}

greets('Shashi');