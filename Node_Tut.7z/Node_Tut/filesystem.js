let fs1 = require('fs')

// ReadFile
// fs1.readFile('D:/NodeWorks/file1.txt', (err,data) => {
//     if(err)
//     {
//         console.log(err)
//     }
//     console.log(data.toString())
// })

// Writing file
// fs1.writeFile('./file1.txt','This text from filesystem ', () => {
//     console.log("File is replaced")
// }) 

// // Folder Creation
// fs1.mkdir('./SimpleFile',(err) => {
//     if(err)
//     {
//         console.log(err)
//     }
//     console.log("File is created")
// })


// // remove directory
// fs1.rmdir('./SimpleFile',(err) => {
//     if(err)
//     {
//         console.log(err)
//     }
//     console.log("File simpleFile is Deleted")
// })

// // Check file existence
// if(fs1.existsSync('./SimpleFile'))
// {
//     console.log("File is Exist")
// }
// else
// {
//     console.log("Not is not created")
// }

// // Check and Create if not Exist else delete the file
// if(fs1.existsSync('./SimpleFile'))
// {
//     console.log("File already Exists")
//     fs1.rmdir('./SimpleFile', (err) =>
//     {
//         if(err)
//         {
//             console.log(err)
//         }
//         console.log("File is deleted")
//     })
// }
// else
// {
//     fs1.mkdir('./SimpleFile', (err) =>{
//         if(err)
//         {
//             console.log(err)
//         }
//         console.log("New File is created")
//     })
// }


// Delete the file in the directory
if(fs1.existsSync('./deleteme.txt'))
{
    fs1.unlink('./deleteme.txt', (err) =>
    {
        if(err)
        {
            console.log(err)
        }
        console.log("deleted successfully")
    })
}
else
{
    console.log("File is Not exists")
}