
// const RD = fs1.createReadStream('./BlockOfData.txt',{ encoding : 'utf8'})
// // const RD = fs1.createReadStream('./BlockOfData.txt')

// RD.on('data', (ck) => {
//     console.log('---------------------------------------New Chunk---------------------------------------')
//     // console.log(ck.toString()
//     console.log(ck)
// })

const fs1 = require('fs')

const RD = fs1.createReadStream('./BlockOfData.txt',{encoding : 'utf8'})
const WD = fs1.createWriteStream('./Block_1.txt')

RD.on('data', (ck) => {
    console.log('----------------New Chunk----------------')
    // console.log(ck)
    WD.write('\nNew Chunk\n')
    WD.write(ck)
})