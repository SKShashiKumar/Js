// //Create Server
// const http = require('http')

// const server = http.createServer((req, res) => {
//     console.log("Server Created")
// })

// server.listen(3000, 'localhost',() => {
//     console.log("Server is running from port 3000")
// })


// // Get request
// const http = require('http')

// const server = http.createServer((req, res) => {
//     console.log(req.url,req.method)
// })

// server.listen(3000,'localhost', () => {
//     console.log("Server is Running in 3000")
// })


// //GET Response
// const http = require('http')

// const server = http.createServer((req, res) => {
//     console.log(req.url, req.method)
//     res.setHeader('Content-Type' , 'text/plain')
//     res.write("Hello ")
//     res.end('Hello world')
// })
// server.listen(3000,'localhost',() =>{
//     console.log("Server is listing from port 3000")
// })


// //output html code
// const http = require('http')

// const server = http.createServer((req, res) => {
//     console.log(req.url)
//     res.setHeader('Content-Type','text/html')
//     res.write("<p><h1>Hello World!!!</h1>This is the example text</p>")
//     res.end()
// })

// server.listen(3000,'localhost',() => {
//     console.log("server is running in localhost:3000")
// })


// // return html file
// const http = require('http')
// const fs = require('fs')

// const server = http.createServer((req, res) => {
//     fs.readFile('./index.html',(err,data) => {
//         res.end((err) ? console.log("Error") : data)
//     })
// })

// server.listen(3000, 'localhost', () => {
//     console.log("Sever is running at 3000")
// })



// // Routing
// const http = require('http')
// const fs = require('fs')

// const server = http.createServer((req, res) => {
//     let path = './'
    
//     res.setHeader('Content-Type' ,'text/html')

//     switch(req.url)
//     {
//         case '/':
//             path += 'index.html'
//             break
        
//         case '/about':
//             path += 'about.html'
//             break 
        
//         default:
//             path += '404.html'
//             break
//     }

//     fs.readFile(path, (err,data) => {
//         if(err)
//         {
//             console.log(err)
//         }
//         res.write(data)
//         res.end()
//     })
// })

// server.listen(3000, 'localhost', () => {
//     console.log("Server is running in 3000")
// })


const http = require('http')
const fs = require('fs')

const server = http.createServer((req, res) => {
    res.setHeader('Content-Type', 'text/html')

    let path = './'

    switch(req.url)
    {
        case '/':
            path += 'index.html'
            res.statusCode = 200
            break

        case '/about':
            path += 'about.html'
            res.statusCode = 200
            break

        default:
            path += '404.html'
            res.statusCode = 404
            break
    }

    fs.readFile(path,(err,data) => {
        if(err)
        {
            console.log(err)
        }
        res.write(data)
        console.log(path)
        res.end()
    })
})

server.listen(3000, 'localhost',() =>{
    console.log("Server is running in 3000")
})