let names = ['Shashi','Harish','Niscith','Akash']

let sgpa = [5.8, 5.6, 4.7, 7.5]

// Single instance 
// module.exports = names

// Multiple Data send
module.exports = {
    names,
    sgpa
}
