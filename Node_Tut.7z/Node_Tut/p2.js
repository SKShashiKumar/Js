/* Single instance
let nam = require('./p1')
console.log(nam)*/

// multiple instance

let { names, sgpa } = require('./p1')

console.log(names)
console.log(sgpa)



