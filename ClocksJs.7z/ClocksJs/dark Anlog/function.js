window.onload = ()=>{
    circle = document.querySelector('circle');
    const circumference = Math.PI * 90;
 
    setInterval(function() {
        let date = new Date();
        let hour = date.getHours();
        let min = date.getMinutes();
        let sec = date.getSeconds();
        let val = ((60-sec)/60) * circumference;
        
        document.querySelector('#hr').style.transform = 'rotate(' + (hour * 360/12 + ((min * 360/60)/12)) + 'deg)';
        document.querySelector('#min').style.transform = 'rotate(' + ((min * 360/60) + (sec* 360/60)/60) + 'deg)';
 
        circle.style.strokeDashoffset = val + '%' ;
    },1000);
}