var am_pm,dayno;
        
//CALLS DATE PER 0.001S
setInterval(mngr,100);
 
//MANAGER
function mngr(){
progbar();
setTimeDate();
};
 
//ONE TIME CALL FOR DATE
dt();
 
//GET DATE TIME PM AM
function dt(retrnVal){
    dateA= new Date();
    
    a=dateA.getHours();
    if (a>12){a-=12; am_pm ="PM";}
    else{if(a==0){a=12;}; am_pm="AM";};
    
    a=fx(a);
    b=fx(dateA.getMinutes());
    c=fx(dateA.getSeconds());
    
    dayno=dateA.getDay();
    day=fx("day");
    date=fx(dateA.getDate());
    month=fx(dateA.getMonth()+1);
    year=dateA.getFullYear();
    
    tym=a+":"+b+":"+c;
    dmy=date+"/"+month+"/"+year;
    return retrnVal;
};
 
//SMALL FIX FOR DATE
function fx(num){
    if (num<=9){num="0"+num;};
    if (num=="day"){
        num=dayno;
        switch (num){
            case 1:
            num="MON";
            break;
            case 2:
            num="TUE";
            break;
            case 3:
            num="WED";
            break;
            case 4:
            num="THU";
            break;
            case 5:
            num="FRI";
            break;
            case 6:
            num="SAT";
            break;
            case 0:
            num="SUN";
            break;
        };
    };
    return num;
};
 
//SETS DATE, TIME, DAY
function setTimeDate(){
    tyme.innerHTML=dt(tym);
    ampm.innerHTML=am_pm;
    daay.innerHTML=dt(day);
    ddmmyyyy.innerHTML =dt(dmy);
};
 
//PROGRESS BAR
function progbar(){
    a1.style.strokeDasharray=300+(dt(c)/60)*(584-300)+"%";
    b = (dt(b)==0) ? 0.01 :dt(b);
    a2.style.strokeDasharray=300+(b/60)*(556-300)+"%";
    a = (dt(a)==12) ? 0.001 :dt(a);
    a3.style.strokeDasharray=300+(a/12)*(533-300)+"%";
};
 
//CHANGES BACKGROUND
axc=(dt(c)/60)*255;
ayc=(dt(c)/60)*127;
 
setInterval(changeColor,100);
function changeColor(){
x=lnrGrdnt();
document.body.style="background:"+x+";";
};
function lnrGrdnt(){
axc++;
ayc--;
if (axc>360){axc=0};
if (ayc<0){ayc=360};
asz="linear-gradient(30deg,hsl("+axc+",100%,40%),hsl("+ayc+",100%,40%))"
    return asz;
};